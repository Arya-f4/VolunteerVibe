// lib/pocketbase_client.dart
import 'package:pocketbase/pocketbase.dart';

const String pocketbaseUrl = 'http://127.0.0.1:8090';
final PocketBase pb = PocketBase(pocketbaseUrl);